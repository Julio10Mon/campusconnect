import 'package:flutter/material.dart';

/// Paleta de marca de CampusConnect — Universidad Tecnológica del Valle
/// del Mezquital.
///
/// Los colores de marca (navy, blue, lightBlue, orange) se mantienen
/// fijos entre modo claro y oscuro para conservar identidad visual
/// (es el mismo criterio que usan apps como WhatsApp o Slack con su
/// barra superior). Los tonos neutros (fondo, superficies, texto) sí
/// cambian entre modos — se definen como [ColorScheme] en AppTheme y
/// se consumen en pantalla con `Theme.of(context).colorScheme`, nunca
/// como constantes fijas, para que el modo oscuro funcione de verdad.
class AppColors {
  AppColors._();

  // ---- Marca (fijos en ambos modos) ----
  static const Color navy = Color(0xFF0C1A33);
  static const Color navyDark = Color(0xFF091426); // variante para AppBar en modo oscuro
  static const Color blue = Color(0xFF2166E8);
  static const Color blueDark = Color(0xFF5B93F5); // variante con más contraste sobre fondo oscuro
  static const Color lightBlue = Color(0xFF3FA9F5);
  static const Color orange = Color(0xFFF5821F);
  static const Color orangeDark = Color(0xFFFF9D4D); // variante con más contraste sobre fondo oscuro

  // ---- Semánticos (fijos, funcionan razonablemente en ambos modos) ----
  static const Color success = Color(0xFF2E7D32);
  static const Color error = Color(0xFFD32F2F);
  static const Color errorDark = Color(0xFFFF6B6B);

  // ---- Neutros — modo claro ----
  static const Color bgLight = Color(0xFFF5F7FB);
  static const Color surfaceLight = Color(0xFFFFFFFF);
  static const Color surfaceAltLight = Color(0xFFEFF3F9); // tarjetas secundarias, chips
  static const Color onSurfaceLight = Color(0xFF161B26);
  static const Color onSurfaceVariantLight = Color(0xFF5B6472);
  static const Color outlineLight = Color(0xFFE1E6EF);

  // ---- Neutros — modo oscuro ----
  static const Color bgDark = Color(0xFF0A0F1C);
  static const Color surfaceDark = Color(0xFF141B2C);
  static const Color surfaceAltDark = Color(0xFF1C2438); // tarjetas secundarias, chips
  static const Color onSurfaceDark = Color(0xFFE9ECF3);
  static const Color onSurfaceVariantDark = Color(0xFFA0A9BB);
  static const Color outlineDark = Color(0xFF2A3350);
}
