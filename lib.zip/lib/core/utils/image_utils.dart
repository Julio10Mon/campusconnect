import 'dart:convert';
import 'dart:typed_data';

import 'package:image_picker/image_picker.dart';

/// Selección y compresión de imágenes para guardarlas como texto
/// (base64) directamente en un documento de Firestore.
///
/// No se usa Firebase Storage a propósito: Storage requiere activar el
/// plan de pago Blaze, y para las fotos de este proyecto (avisos,
/// eventos, perfil, mapa) una imagen comprimida cabe perfectamente
/// dentro del límite de 1 MiB por documento de Firestore.
class ImageUtils {
  ImageUtils._();

  static final ImagePicker _picker = ImagePicker();

  /// Abre la galería o la cámara, comprime la imagen elegida y devuelve
  /// su representación en base64. Devuelve `null` si el usuario cancela.
  /// Lanza una excepción si, aun comprimida, la imagen es demasiado
  /// grande para guardarse en un documento de Firestore.
  static Future<String?> pickAndEncodeImage({
    ImageSource source = ImageSource.gallery,
  }) async {
    final XFile? file = await _picker.pickImage(
      source: source,
      maxWidth: 900,
      maxHeight: 900,
      imageQuality: 70,
    );
    if (file == null) return null;

    final Uint8List bytes = await file.readAsBytes();

    // Firestore limita cada documento a 1 MiB. Dejamos margen amplio
    // para el resto de los campos del documento.
    const maxBytes = 700 * 1024;
    if (bytes.lengthInBytes > maxBytes) {
      throw Exception(
        'La imagen es demasiado grande incluso comprimida. Prueba con otra foto.',
      );
    }

    return base64Encode(bytes);
  }
}
