import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

/// Handler de mensajes en segundo plano. Debe ser una función de nivel
/// superior (top-level) o estática, tal como exige el plugin.
@pragma('vm:entry-point')
Future<void> firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  // Aquí se podría, por ejemplo, actualizar un contador de avisos no
  // leídos en almacenamiento local. Se deja como referencia para el
  // equipo de desarrollo.
  debugPrint('Notificación recibida en segundo plano: ${message.messageId}');
}

/// Encapsula la configuración de Firebase Cloud Messaging y de las
/// notificaciones locales usadas para mostrarlas en primer plano.
class NotificationService {
  final FirebaseMessaging _messaging = FirebaseMessaging.instance;
  final FlutterLocalNotificationsPlugin _localNotifications =
      FlutterLocalNotificationsPlugin();

  static const _channel = AndroidNotificationChannel(
    'campusconnect_avisos',
    'Avisos institucionales',
    description: 'Notificaciones de avisos y eventos de CampusConnect.',
    importance: Importance.high,
  );

  Future<void> initialize() async {
    await _messaging.requestPermission(alert: true, badge: true, sound: true);

    const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    const initSettings = InitializationSettings(android: androidInit);
    await _localNotifications.initialize(initSettings);

    final androidPlugin = _localNotifications
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    await androidPlugin?.createNotificationChannel(_channel);

    // Notificación recibida con la app abierta en primer plano.
    FirebaseMessaging.onMessage.listen(_showLocalNotification);
  }

  Future<String?> getDeviceToken() => _messaging.getToken();

  Stream<String> get onTokenRefresh => _messaging.onTokenRefresh;

  Future<void> _showLocalNotification(RemoteMessage message) async {
    final notification = message.notification;
    if (notification == null) return;

    await _localNotifications.show(
      notification.hashCode,
      notification.title,
      notification.body,
      NotificationDetails(
        android: AndroidNotificationDetails(
          _channel.id,
          _channel.name,
          channelDescription: _channel.description,
          importance: Importance.high,
          priority: Priority.high,
        ),
      ),
    );
  }
}
