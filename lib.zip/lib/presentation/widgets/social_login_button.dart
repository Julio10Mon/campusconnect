import 'package:flutter/material.dart';

/// Botón de inicio de sesión con un proveedor externo (Google, Facebook).
/// Muestra un ícono o imagen representativa, el texto, y un indicador de
/// carga propio para no bloquear los demás botones mientras se resuelve.
class SocialLoginButton extends StatelessWidget {
  final IconData? icon;
  final Color? iconColor;
  final String? iconAsset;
  final String label;
  final VoidCallback? onPressed;
  final bool isLoading;

  const SocialLoginButton({
    super.key,
    this.icon,
    this.iconColor,
    this.iconAsset,
    required this.label,
    required this.onPressed,
    this.isLoading = false,
  }) : assert(icon != null || iconAsset != null, 'Provee icon o iconAsset.');

  @override
  Widget build(BuildContext context) {
    return OutlinedButton(
      onPressed: isLoading ? null : onPressed,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          if (isLoading)
            const SizedBox(
              width: 18,
              height: 18,
              child: CircularProgressIndicator(strokeWidth: 2.2),
            )
          else if (iconAsset != null)
            Image.asset(
              iconAsset!,
              width: 20,
              height: 20,
              fit: BoxFit.contain,
              // Blindaje: si el asset no carga por cualquier motivo (por
              // ejemplo, alguien olvida copiar la carpeta assets/ o
              // actualizar pubspec.yaml), se ve un ícono simple en vez
              // de un cuadro de error que desborda el botón.
              errorBuilder: (context, error, stackTrace) => const Icon(Icons.login, size: 20),
            )
          else
            Icon(icon, color: iconColor, size: 20),
          const SizedBox(width: 10),
          Flexible(child: Text(label, overflow: TextOverflow.ellipsis)),
        ],
      ),
    );
  }
}
