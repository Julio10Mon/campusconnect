import 'package:flutter/material.dart';

/// Logo oficial de CampusConnect, como componente único reutilizado en
/// toda la app (splash, login, registro, y el ícono pequeño en cada
/// encabezado de pantalla). Usar siempre este widget — nunca
/// `Image.asset('assets/icon/icon.png')` directo — para que el logo
/// nunca se deforme ni pierda resolución, y para poder actualizarlo
/// desde un solo lugar en el futuro.
class LogoApp extends StatelessWidget {
  /// Tamaño del lado (el logo es cuadrado). Ej: 32 para un ícono de
  /// AppBar, 84 para la pantalla de login, 120 para el splash.
  final double size;

  /// Qué tan redondeadas son las esquinas, proporcional a [size] por
  /// defecto (mismo radio visual sin importar el tamaño).
  final BorderRadius? borderRadius;

  const LogoApp({super.key, this.size = 48, this.borderRadius});

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: borderRadius ?? BorderRadius.circular(size * 0.26),
      child: Image.asset(
        'assets/icon/icon.png',
        width: size,
        height: size,
        // BoxFit.contain: nunca deforma el logo ni lo recorta, sin
        // importar el tamaño de pantalla del dispositivo.
        fit: BoxFit.contain,
        filterQuality: FilterQuality.high,
      ),
    );
  }
}
