import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/user_model.dart';

/// Encapsula las operaciones administrativas sobre la colección
/// `usuarios` que solo un administrador puede realizar: listar a todos,
/// cambiar el rol de alguien, activar/desactivar una cuenta, o editar
/// los datos de otra persona. Las reglas de seguridad (firestore.rules)
/// exigen `rol == 'admin'` para todo lo que no sea leer o editar el
/// propio documento — esta clase es el reflejo, en el cliente, de esas
/// mismas reglas.
class UserManagementRemoteDataSource {
  final FirebaseFirestore _firestore;

  UserManagementRemoteDataSource({FirebaseFirestore? firestore})
      : _firestore = firestore ?? FirebaseFirestore.instance;

  Stream<List<UserModel>> watchAllUsers() {
    return _firestore.collection('usuarios').snapshots().map(
          (snapshot) => snapshot.docs.map((doc) => UserModel.fromMap(doc.id, doc.data())).toList(),
        );
  }

  Future<void> updateRole(String uid, UserRole rol) {
    return _firestore.collection('usuarios').doc(uid).update({'rol': roleToString(rol)});
  }

  Future<void> setActive(String uid, bool activo) {
    return _firestore.collection('usuarios').doc(uid).update({'activo': activo});
  }

  /// Edita nombre y carrera de OTRO usuario (uso administrativo). No
  /// toca correo, rol, ni estado de la cuenta — eso tiene sus propios
  /// métodos, para que cada acción quede clara y auditable por separado.
  Future<void> updateUserInfo(String uid, {required String nombre, String? carrera}) {
    return _firestore.collection('usuarios').doc(uid).update({
      'nombre': nombre,
      'carrera': carrera,
    });
  }
}
