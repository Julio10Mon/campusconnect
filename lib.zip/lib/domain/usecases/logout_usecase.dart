import '../repositories/auth_repository.dart';

/// Caso de uso: cerrar la sesión activa.
class LogoutUseCase {
  final AuthRepository _repository;
  LogoutUseCase(this._repository);

  Future<void> call() => _repository.logout();
}
