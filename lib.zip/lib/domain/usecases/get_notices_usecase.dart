import '../../data/models/notice_model.dart';
import '../repositories/academic_repository.dart';

/// Caso de uso: observar en tiempo real los avisos institucionales.
class GetNoticesUseCase {
  final AcademicRepository _repository;
  GetNoticesUseCase(this._repository);

  Stream<List<NoticeModel>> call() => _repository.watchNotices();
}
