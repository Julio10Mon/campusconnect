import '../../data/models/user_model.dart';

/// Contrato del dominio para el panel de administración de usuarios.
/// Solo tiene sentido para cuentas con rol `admin` (ver
/// firestore.rules y UserManagementScreen).
abstract class UserManagementRepository {
  Stream<List<UserModel>> watchAllUsers();

  Future<void> updateRole(String uid, UserRole rol);

  Future<void> setActive(String uid, bool activo);

  Future<void> updateUserInfo(String uid, {required String nombre, String? carrera});
}
